#ifndef WALLCLOCKTIME_H
#define WALLCLOCKTIME_H

void set_time_base(void);
double get_time_in_seconds(void);

#endif
